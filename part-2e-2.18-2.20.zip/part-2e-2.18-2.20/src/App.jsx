import { useState, useEffect } from "react"
import axios from "axios"
import CountryDetail from "./components/CountryDetail"

const App = () => {
  const [countries, setCountries] = useState([])
  const [search, setSearch] = useState("")
  const [selectedCountry, setSelectedCountry] = useState(null)

  useEffect(() => {
    axios
      .get("https://studies.cs.helsinki.fi/restcountries/api/all")
      .then((response) => setCountries(response.data))
  }, [])

  const handleSearchChange = (event) => {
    setSearch(event.target.value)
    setSelectedCountry(null) // Reset selected country on input change
  }

  const filteredCountries = countries.filter((country) =>
    country.name.common.toLowerCase().includes(search.toLowerCase())
  )

  const showCountry = (country) => {
    setSelectedCountry(country)
  }

  return (
    <div>
      <h1>🌍 Country Finder</h1>
      <div>
        Find countries:{" "}
        <input value={search} onChange={handleSearchChange} />
      </div>

      {selectedCountry ? (
        <CountryDetail country={selectedCountry} />
      ) : filteredCountries.length > 10 ? (
        <p>Too many matches, specify another filter</p>
      ) : filteredCountries.length === 1 ? (
        <CountryDetail country={filteredCountries[0]} />
      ) : (
        filteredCountries.map((country) => (
          <div key={country.cca3}>
            {country.name.common}{" "}
            <button onClick={() => showCountry(country)}>show</button>
          </div>
        ))
      )}
    </div>
  )
}

export default App
